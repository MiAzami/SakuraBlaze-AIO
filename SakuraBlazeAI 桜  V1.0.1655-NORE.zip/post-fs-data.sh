#!/sbin/sh
MODDIR=${0%/*}

sleep 5

# tombstoned
resetprop -n tombstoned.max_tombstone_count 0

# low memory killer
resetprop -n ro.lmk.debug false
resetprop -n ro.lmk.log_stats false
