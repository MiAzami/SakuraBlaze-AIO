# Set permissions

ui_print " "
ui_print " Module info: "
ui_print " • Name            : SakuraBlazeAI"
ui_print " • Codename        : Helio GORE—99"
ui_print " • Version         : V1.0.1655 NoRender"
ui_print " • Status          : Public Release "
ui_print " • Owner           : MiAzami "
ui_print " • Build Date      : 04-06-2024"
ui_print " • Support Varians : Ultimate/Ultra"
ui_print " "
ui_print " Device info:"
ui_print " • Brand           : $(getprop ro.product.system.brand) "
ui_print " • Device          : $(getprop ro.product.system.model) "
ui_print " • Processor       : $(getprop ro.product.board) "
ui_print " • Android Version : $(getprop ro.system.build.version.release) "
ui_print " • SDK Version     : $(getprop ro.build.version.sdk) "
ui_print " • Architecture    : $(getprop ro.product.cpu.abi) "
ui_print " • Kernel Version  : $(uname -r) "
ui_print " "
ui_print " Thanks To:"
sleep 0.2
ui_print " — MiAzami"
sleep 0.2
ui_print " — Riprog"
sleep 0.2
ui_print " — All Tester"
sleep 0.2
ui_print " — All Dev Re;Surrection"
sleep 0.2
ui_print " "

sleep 1
ui_print " ================================================"
ui_print "                  ‼️ 𝙒𝘼𝙍𝙉𝙄𝙉𝙂 ‼️"
ui_print " "
ui_print " "
ui_print " 𝘿𝙤𝙣𝙩 𝙐𝙨𝙚, 𝘼𝙥𝙥𝙡𝙮 𝘼𝙣𝙮 :"
ui_print " — 𝘛𝘸𝘦𝘢𝘬𝘴 / 𝘔𝘰𝘥 / 𝘖𝘱𝘵𝘪𝘮𝘪𝘻𝘢𝘵𝘪𝘰𝘯 𝘗𝘦𝘳𝘧𝘰𝘳𝘮𝘢𝘯𝘤𝘦"
ui_print " "
ui_print " [ 𝘖𝘯𝘭𝘺 𝘢𝘱𝘱𝘳𝘰𝘷𝘦𝘥 𝘮𝘰𝘥𝘪𝘧𝘪𝘤𝘢𝘵𝘪𝘰𝘯𝘴 𝘧𝘳𝘰𝘮 𝘵𝘳𝘶𝘴𝘵𝘦𝘥 𝘥𝘦𝘷𝘦𝘭𝘰𝘱𝘦𝘳𝘴"
ui_print " 𝘴𝘩𝘰𝘶𝘭𝘥 𝘣𝘦 𝘶𝘴𝘦𝘥 𝘵𝘰 𝘦𝘯𝘴𝘶𝘳𝘦 𝘤𝘰𝘯𝘵𝘪𝘯𝘶𝘦𝘥 𝘯𝘰𝘳𝘮𝘢𝘭 𝘧𝘶𝘯𝘤𝘵𝘪𝘰𝘯𝘪𝘯𝘨"
ui_print " 𝘢𝘯𝘥 𝘱𝘳𝘦𝘷𝘦𝘯𝘵 𝘱𝘰𝘵𝘦𝘯𝘵𝘪𝘢𝘭 𝘪𝘴𝘴𝘶𝘦𝘴. ]"
ui_print " "
ui_print "   𝘼𝙡𝙡𝙤𝙬 𝙏𝙤𝙖𝙨𝙩 𝙖𝙥𝙥𝙨 𝙞𝙛 𝙩𝙝𝙖𝙩 𝙙𝙚𝙩𝙚𝙘𝙩𝙚𝙙 𝙬𝙞𝙩𝙝 𝙋𝙡𝙖𝙮 𝙎𝙚𝙘𝙪𝙧𝙚"
ui_print " ================================================"
ui_print " Preparing Settings..."
sleep 5
# Set permissions
ui_print " ⚙️ Settings permissions"
sleep 0.5
ui_print " Apply Tweaks & Settings: ✅"
ui_print " "
ui_print " Preparing Settings..."
ui_print " ⚙️ Setting permissions"

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/script 0 0 0755 0755
set_perm_recursive $MODPATH/vendor 0 0 0755 0755

# Install toast app
ui_print " 📲 Install Toast app"
pm install $MODPATH/Toast.apk
ui_print " "

# Clean up
find $MODPATH/* -maxdepth 0 \
              ! -name 'module.prop' \
              ! -name 'post-fs-data.sh' \
              ! -name 'service.sh' \
              ! -name 'sepolicy.rule' \
              ! -name 'system.prop' \
              ! -name 'uninstall.sh' \
              ! -name 'system' \
              ! -name 'script' \
              ! -name 'vendor' \
                -exec rm -rf {} \;

# Check rewrite directory
if [ ! -e /storage/emulated/0/SakuraAi ]; then
  mkdir /storage/emulated/0/SakuraAi
fi

# Check applist file
if [ ! -e /storage/emulated/0/SakuraAi/applist_perf.txt ]; then
  cp -f $MODPATH/script/applist_perf.txt /storage/emulated/0/SakuraAi
fi

nohup am start -a android.intent.action.VIEW -d https://t.me/mtkvestg99 >/dev/null 2>&1 &
